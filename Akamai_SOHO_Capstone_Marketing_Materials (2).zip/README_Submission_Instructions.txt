AKAMAI SOHO SECURE — CAPSTONE SUBMISSION PACK

CONTENTS
1. Akamai_SOHO_Phishing_Awareness_Presentation.pptx
   A five-slide, narration-ready presentation. Speaker notes are included on each slide.
2. Video_Narration_Script.txt
   Complete narration script for a video of approximately 2–3 minutes.
3. Akamai_SOHO_Phishing_Security_Poster.pdf
   A one-page security poster with a short risk explanation and five mitigation actions.

IMPORTANT: The PowerPoint is a presentation source, not an MP4 video. To meet a requirement for a video:
1. Open the PPTX in Microsoft PowerPoint.
2. Select Slide Show > Record (or Record Slide Show).
3. Read the narration script while advancing through the slides.
4. Keep the total recording at or below 3 minutes.
5. Export using File > Export > Create a Video, then choose MP4.
6. Replace the PPTX in this ZIP with the exported MP4, or include both the MP4 and PPTX.

SUBMISSION
Submit this ZIP file to your course platform. Before submitting, make sure the ZIP contains the actual MP4 video (or a document with a working online video link) and the PDF poster, as required by your instructor.
